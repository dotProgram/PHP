define([], function() {
	var model = {
		ComponentName: 'pignoseCalendar',
		ComponentVersion: '1.4.16',
		ComponentPreference: {
			supports: {
				themes: ['light', 'dark', 'blue']
			}
		}
	};
	return model;
});
